Departemen di UC:
Biro Administrasi Akademik
Biro Mahasiswa dan Alumni
Perpustakaan
Pusat Pengembangan Pendidikan dan Pembelajajaran
Lembaga Penelitian & Pengabdian Masyarakat
Penjaminan Mutu
Pusat Pengembangan Teknologi Informasi dan Komunikasi
Biro Manajemen Sumber Daya Manusia
Biro Pengelolaan Aset dan Gedung
Biro Keuangan dan Akuntansi
Networking and Partnership Department
Career and Alumni Development

Tugas Biro Administrasi Akademik:
Melakukan kegiatan administrasi akademik.
Merencanakan dan melaksanakan kegiatan akademik.
Memonitor dan mengevaluasi kegiatan akademik.

Tugas Biro Mahasiswa dan Alumni :
Mengelola kegiatan kemahasiswaan dan alumni.
Merencanakan dan melaksanakan pembinaan terhadap organisasi kemahasiswaan.
Merencanakan dan melaksanakan pembinaan terhadap kegiatan ekstra kurikuler mahasiswa.
Menjaga hubungan baik dengan Ikatan Alumni UC.
Unit Kegiatan Mahasiswa (UKM)

Selain belajar secara akademis, disini kalian akan ada banyak kegiatan non-akademis yang terkategorikan dalam Unit Kegiatan Mahasiswa (UKM). Sebagai anak muda yang punya energi lebih, ayo kita manfaatkan energi kita untuk hal-hal yang positif.

UKM di UC tersedia dalam berbagai dibidang, seperti:
UKM Persekutuan Mahasiswa Kristen
UKM Keluarga Mahasiswa Katholik
UKM Moslem Community UC
UKM Buddhist Community
UKM Hindu Dharma
UKM Abstract
UKM Dance
UKM Theater
UKM Tari Tradisional
UKM Resonance
UKM UC Choir
UKM Kanvas Illustrasi
UKM Fotografi Artupic
UKM Jepang
UKM Balawarta
UKM Mahatra
UKM Board Game
UKM Futsal
UKM Badminton
UKM Basket
UKM Karate
UKM Perisai Diri
UKM Wing Chun
UKM Boxing
UKM Taekwondo

Prestasi UKM UC:
Semi Finalist Tournamen Basket LA Campus League 2017
Juara I Catholic Community Cup 2017 kategori Vocal Grup yang diadakan oleh KMK St. Ignatius ITS
Juara I Kategori 1 on 1 Freestyle Battle Dance Competition 2017 yang diselenggarakan oleh Be The First Vol. 2
Juara I Kategori University Dance Competition 2017 yang diselenggarakan oleh Be The First Vol. 2
Juara 1 kategori Beregu dan peringkat 9 kategori Perorangan dalam Kejuaraan Nasional Golf Amatir 2017
Dan lain lain

Perpustakaan UC mulai beraktifitas sejak diresmikannya Universitas Ciputra pada tanggal 26 Agustus 2006, menempati lantai 6 di #607 terdiri dari ruang koleksi sekaligus ruang baca; area locker; area pelayanan sirkulasi dan ruang Kepala Perpustakaan dengan luas ruang 270M2.
Dengan bertambahnya jumlah koleksi dan kebutuhan sarana prasarana di Universitas Ciputra, menjelang tahun ajaran 2011/2012 LIB menempati ruang di lantai 2 gedung UC3 dengan luas 470M2 terdiri dari  ruang koleksi sekaligus ruang baca; ruang Kepala Perpustakaan; ruang prosesing dan ruang pengolahan Terbitan Berkala; area sirkulasi khusus peminjaman. Selain itu tersedia Lounge yang terdiri dari area Locker; area sirkulasi khusus pengembalian dan perpanjangan; ruang rapat; sarana layanan Personal Computer (PC) untuk layanan Internet dan OnLine Catalog; area layanan foto kopi (sekaligus pelayanan printing dan penjualan ATK) serta area Cable TV.
Koleksi Buku Entrepreneurship, Innovation & Creativity merupakan ciri khas koleksi kami di samping koleksi-koleksi umum:  Buku Teks; Referensi; Koleksi Deposit (koleksi titipan dosen/staf), Terbitan Berkala, TA/Skripsi, Jurnal; Audio Visual (DVD, VCD, VHS, CD, Kaset).
Jam Layanan perpustakaan
Senin-Jumat : 07.30-18.00 WIB
Sabtu : 07.30-16.30 WIB
Hari Raya/Besar/Minggu : Tutup
Universitas Ciputra dapat melayani Kartu SUPER
kartu yang digunakan untuk mengakses layanan seluruh perpustakaan yang tergabung dalam FPPTI Jawa Timur. Dengan Kartu SUPER (Sarana Untuk ke Perpustakaan) ini, Anda tidak perlu lagi mengurus surat ijin untuk ke masing-masing perpustakaan anggota FPPTI Jatim jika ingin menggunakan layanan suatu perpustakaan.
Kartu SUPER ini diluncurkan bersamaan dengan Seminar Keterbukaan Informasi Publik dan Deklarasi FPPTI Jawa Timur pada tanggal 26 Juli 2010 yang lalu.


Pusat pengembangan pendidikan dan pembelajaran disingkat TLiC  adalah unit layanan yang mendukung kemajuan proses belajar mengajar di Universitas Ciputra yang dalam aktivitas organisasi. TLiC berfokus untuk meningkatkan kualitas pengajaran, melakukan asssesment terkait trend dan kebutuhan belajar mahasiswa dan memperkuat hubungan lintas departemen untuk menumbuhkan komunitas akademik yang dinamis.
Tugas Pokok dan Fungsi TLiC
Menyusun rencana strategis departemen berdasarkan rencana strategis universitas
Menyusun program kerja dan anggaran tahunan departemen serta mengelola anggaran dengan efektif dan efisien
Menyusun dan mengimplementasikan standar mutu dan sistem pembelajaran yang efektif dan efisien
Merencanakan dan menyelenggarakan pelatihan-pelatihan bagi peningkatan kompetensi pedagogis tenaga pendidik
Mengkoordinasikan penyusunan kurikulum program studi berpedoman pada ketentuan dan peraturan akademik terkait visi dan misi UC
Menyusun dan menyampaikan laporan kinerja secara berkala kepada Wakil Rektor Bidang Akademik

Lembaga penelitian dan pengabdian masyarakat atau The Institute for Research and Community Service (LPPM) of Ciputra University Surabaya has the task of coordinating, planning, implementing, and evaluating the performance of the tridharma, especially the implementation of research and community service within the Ciputra University Surabaya environment.
LPPM UC Focus
Improving the quality of research and community service, in the fields of science and entrepreneurship.
Improving the quality of entrepreneurial management of Research and Community Service Institutions .
Continuous improvement in accordance with national and international standards.

Tugas Departemen Penjaminan Mutu (Quality Assurance) disingkat QA :
Mengkoordinasikan penyusunan Sistem Penjaminan Mutu Internal (SPMI) untk mengendalikan mutu penyelenggaraan tridarma perguruan tinggi
Melaksanakan audit internal dan mengkoordinasikan pelaksanaan audit eksternal
Melaksanakan survei kepuasan pelanggan baik internal ataupun eksternal
Memantau dan mengkoordinasikan tindak lanjut hasil audit, keluhan pelanggan & hasil survei kepuasan pelanggan
Memberikan saran dan rekomendasi perbaikan berkesinambungan kepada Rektor atas pemantauan implementasi SPMI

Tugas Departemen Pusat Pengembangan Teknologi Informasi dan Komunikasi :
Mengembangkan teknologi informasi dan komunikasi untuk memenuhi kebutuhan UC.
Mengembangkan dan mengimplementasikan teknologi informasi dan komunikasi untuk menunjang kegiatan akademik dan operasional UC.
Menyediakan sarana yang terkait dengan teknologi informasi dan komunikasi sesuai dengan kebutuhan.

Tugas Departemen Biro Manajemen Sumber Daya Manusia disingkat HCM:
Mengelola sumber daya manusia.
Merencanakan dan menyelenggarakan pelatihan-pelatihan yang diperlukan untuk pengembangan kompetensi tenaga kependidikan.
Merencanakan dan memenuhi kebutuhan sumber daya manusia bagi keberlangsungan proses pembelajaran.
Menegakkan peraturan dan etika kepegawaian di seluruh UC.

Tugas Departemen Biro Pengelolaan Aset dan Gedung disingkat PM:
Mengelola aset dan gedung milik UC.
Merencanakan dan mengembangkan sarana dan prasarana sesuai dengan kebutuhan.
Melakukan administrasi dan pemeliharaan terhadap aset dan gedung milik UC.

Tugas Departemen Biro Keuangan dan Akuntansi disingkat FA:
Menyelenggarakan pembukuan UC.
Memonitor dan mengevaluasi anggaran dan penggunaannya.
Melaksanakan administrasi keuangan mahasiswa.