Kontak Universitas Ciputra (UC)
Universitas Ciputra
CitraLand CBD Boulevard, Made, Kec. Sambikerep Surabaya, Jawa Timur 60219
Whatsapp/telp: Program Sarjana (S1) : 0822 3494 1824
Whatsapp/telp: Program Pascasarjana (S2 & S3): 0838 4934 3601
Line:@ucpeople
Instaram:universitasciputra
improvement box
Fitur ini digunakan untuk memberikan masukan bagi UC. Untuk informasi lainnya (penawaran, undangan, dll.) dapat disampaikan melalui email info@ciputra.ac.id

