List Tempat Tinggal Dekat UC Ada Kos, UC Apartement, sewa rumah, HOLA (Hotel Lab)

Informasi Kos Sekitar Universitas Ciputra:
Terdapat banyak kos didekamn universitas ciputra, beberapa diantaranya
1. UC STUDENT RESIDENCE, 081232683568, Sentra Niaga Utama CTC X-26
2. Rainbow Kos, 081803013902, Water Front Water Park 3/6
3. House of Joy, 0816516032, Taman Puspa Raya Blok C3 NO. 1

UC Apartment:
UC Apartment dengan tiga (3) tower yaitu Berkeley, Cornell, dan Denver ini sebagai icon dari Student & Young Urban Professional Apartment di Surabaya. Tower pertama, Berkeley terdiri 502 unit sudah beroperasi sejak awal tahun 2010. Tower kedua, Cornell terdiri atas 416 unit dan Tower ketiga, Denver terdiri 642 unit sudah beroperasi sejak tahun 2020. Apartemen dengan konsep minimalis ini dapat dipergunakan sebagai investasi jangka panjang ataupun dapat dihuni dengan sistem kontrak.
Pengalaman unik menanti Anda dan keluarga di sini. Untuk memanjakan dan memudahkan gaya hidup penghuninya. UC APARTEMENT di lengkapi dengan beragam fasilitas keluarga yang modern seperti :

Lobby yg nyaman dan tersedia coworking space
Di lt 8 Denver tersedia E-Deck yg dilengkapi :
* swimming pool (adult+kids) , masing-masing tower memiliki swimming pool terpisah
* jacuzzi
* sauna dan shower room
* Gym
* Outdoor Gym dan Jogging Track
* Outdoor Coworking Space
* Lounge
Retail Area
Area parkir outdoor dan gedung parker
Di sini Anda berada di satu kompleks dengan Universitas Ciputra – Universitas terkemuka dengan visi mencetak entrepreneur berkelas international. Selain itu, Anda hanya selangkah dari Ciputra Golf & Family Club – 27 holes international golf course; Sekolah Ciputra dan Surabaya International School – sekolah swasta dengan kurikulum pendidikan berstandar international untuk putra-putri Anda; serta GWalk – street outdoor dining yang fenomenal di CitraRaya.

Informasi Kontak Apartement UC
+62 851-6124-6686
031-21001686 / 7408686

Rumah / Sewa Kos:
Hadirnya rumah sewa, kos dan mobil antar jemput dengan harga terjangkau di kawasan CitraRaya dan sekitarnya makin mempermudah mahasiswa yang berasal dari luar kota atau luar pulau untuk menuntut ilmunya di UC. Perkembangan kos dan rumah sewa ini sejalan dengan perkembangan mahasiswa UC dari luar kota.
Harga kos bervariasi mulai Rp 600.000,- hingga Rp 2.200.000,- bergantung pada luas kamar dan fasilitas yang tersedia.

Berikut merupakan beberapa rumah kos sekitar wilayah Universitas Ciputra :
1. The Rock, 081252700022, Water Front Water Park 2/17, Mulai dari Rp2.000.000 
2. Kos VTT, 081252173388, Vila Taman Telaga 2 TJ 6/ 18 SA, Mulai dari Rp2.000.000
3. Marina Residence, Kost Wanita Ottiemmo Ciputra, Jl. Puri Widya Kencana No.1, Mulai dari Rp2.600.000

HOLA:
Hotel Lab managed by Hotel & Tourism Business
Universitas Ciputra Surabaya

Hotel dengan konsep minimalis yang dapat di sewa untuk kebutuhan akomodasi harian menyediakan 3 tipe kamar yaitu:
Deluxe Room
Suite Room
Capsule Bed
Berlokasi di Kompleks Sentra Niaga Utama CitraLand Surabaya, hanya 5 menit menuju Universitas Ciputra Surabaya dan GWalk street outdoor dining yang fenomenal di CitraLand.
Informasi harga & pemesanan:
WA : +62 858 29191 791
Email : hola@ciputra.ac.id
