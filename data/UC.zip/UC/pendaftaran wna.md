PERATURAN PENDAFTARAN WNA  :
Universitas Ciputra menerima pendaftaran Warga Negara Asing (WNA) dengan persyaratan sebagai berikut :
Mendaftar sebagai calon mahasiswa baru Universitas Ciputra
Mengikuti tes seleksi
Menyelesaikan administrasi keuangan
Mengumpulkan kelengkapan untuk pengurusan surat ijin belajar yaitu :
Scan paspor yang masih berlaku minimal untuk 24 bulan kedepan sejak tangal perkuliahan dimulai
Pas foto berwarna 4×6
Surat keterangan kesehatan dari Rumah Sakit
Surat Jaminan Pembiayaan (download di https://www.ciputra.ac.id/pendaftar-wna-2025/)
Surat Pernyataan Patuh Peraturan & Tidak Berpolitik di Indonesia (download di https://www.ciputra.ac.id/pendaftar-wna-2025/)
Surat Pernyataan Tidak Bekerja (download di https://www.ciputra.ac.id/pendaftar-wna-2025/)
Ijazah SMA
Pengurusan surat ijin belajar akan dilakukan oleh Universitas Ciputra
Setelah surat ijin belajar dikeluarkan oleh kemendikbud, calon mahasiswa wajib melakukan registrasi ulang

Q: Hallo
A: Halo! YUCCA di sini. Apa yang bisa YUCCA bantu?

Q: Halo
A: Halo! YUCCA di sini. Apa yang bisa YUCCA bantu?

Q: Hi
A: Halo! YUCCA di sini. Apa yang bisa YUCCA bantu?

Q: Hello
A: Halo! YUCCA di sini. Apa yang bisa YUCCA bantu?
